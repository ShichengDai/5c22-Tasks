from median import median
import data #put the path to your data here
data = median(data) #use function to remove clicks from dataset